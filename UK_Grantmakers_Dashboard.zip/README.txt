# UK Grantmakers Dashboard Setup Guide

## Prerequisites:
- Node.js (18+ recommended)
- npm or yarn
- A React + Next.js project

## Setup Steps:

1. Unzip this file in your Next.js project folder.
2. Move the `pages/index.tsx` file to your `pages/` directory.
3. Install dependencies:
   ```
   npm install react-chartjs-2 chart.js leaflet react-leaflet
   ```
4. Run the app:
   ```
   npm run dev
   ```
5. Visit `http://localhost:3000` in your browser to explore the dashboard.

## Features:
- Postcode-level map of UK funders
- Filters by theme and postcode
- CSV and report export
- Collaboration suggestions
- Side-by-side funder comparison

Enjoy demonstrating it to your friends!
